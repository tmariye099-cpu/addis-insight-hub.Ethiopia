"use client";
import React from 'react';

const featuredLocations = [
  { id: 'unity-park', name: 'Unity Park', excerpt: "A symbol of national unity and Ethiopia's cultural heritage." },
  { id: 'entoto-park', name: 'Entoto Park', excerpt: 'A green highland park with panoramic views and cultural significance.' },
  { id: 'meskel-square', name: 'Meskel Square', excerpt: 'A civic center and venue for national gatherings.' },
];

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      <header className="bg-white shadow">
        <div className="max-w-6xl mx-auto px-6 py-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-gradient-to-br from-yellow-400 to-green-600 rounded-full flex items-center justify-center text-white font-bold">
              AI
            </div>
            <div>
              <h1 className="text-xl font-semibold">Addis Insight Hub</h1>
              <p className="text-sm text-gray-600">Showcasing Ethiopia's culture, tourism, and diplomacy.</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-12">
        <section className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold">Addis Ababa — Culture, Diplomacy & Innovation</h2>
            <p className="mt-4 text-gray-700">
              Addis Insight Hub tells the stories behind public spaces and developments shaping Ethiopia's soft power.
            </p>
            <div className="mt-6 flex gap-4">
              <a href="#discover" className="px-5 py-3 bg-yellow-400 rounded-md font-semibold">Explore Addis</a>
              <a href="#insights" className="px-5 py-3 border rounded-md">Read Insights</a>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-4">
            <div className="h-64 bg-gray-100 rounded-md flex items-center justify-center text-gray-500 text-center">
              <div>
                <div className="font-semibold">Interactive Map Placeholder</div>
                <div className="text-xs mt-2">(Add Leaflet or Mapbox later)</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="text-center text-sm text-gray-600 py-6">
        © {new Date().getFullYear()} Addis Insight Hub — Built with vision by you.
      </footer>
    </div>
  );
}
