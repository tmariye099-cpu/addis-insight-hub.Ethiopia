# Addis Insight Hub 🌍

A modern Next.js + TailwindCSS project showcasing Ethiopia's culture, tourism, and diplomacy.

## 🚀 How to Deploy (from Android)

1. Go to [github.com](https://github.com) and log in.
2. Create a **new repository** called `addis-insight-hub`.
3. Tap **"Add file" → "Upload files"**, then upload all files from this ZIP.
4. Commit the changes.
5. Go to [vercel.com](https://vercel.com), import your repository, and deploy.
6. Done! Your site will be live globally in seconds.

Built with ❤️ for your vision of Addis Ababa.
